package com.coolpayments;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class CoolPaymentsSettingsScreen extends Screen {

    private static final int PANEL_W = 195;

    public CoolPaymentsSettingsScreen() {
        super(Text.literal("Cool Payments"));
    }

    @Override
    protected void init() {
        CoolPaymentsConfig cfg = CoolPaymentsConfig.get();
        int x = 12;
        int y = 50;
        int w = PANEL_W - 24;
        int h = 20;
        int gap = 28;

        this.addDrawableChild(ButtonWidget.builder(
            Text.literal("✨ Particles: " + onOff(cfg.particlesEnabled)),
            btn -> {
                cfg.particlesEnabled = !cfg.particlesEnabled;
                btn.setMessage(Text.literal("✨ Particles: " + onOff(cfg.particlesEnabled)));
                CoolPaymentsConfig.save();
            }).dimensions(x, y, w, h).build());

        this.addDrawableChild(ButtonWidget.builder(
            Text.literal("🎵 Jingle Bells: " + onOff(cfg.musicEnabled)),
            btn -> {
                cfg.musicEnabled = !cfg.musicEnabled;
                btn.setMessage(Text.literal("🎵 Jingle Bells: " + onOff(cfg.musicEnabled)));
                CoolPaymentsConfig.save();
            }).dimensions(x, y + gap, w, h).build());

        this.addDrawableChild(ButtonWidget.builder(
            Text.literal("💰 Confirm >1B: " + onOff(cfg.confirmLargePayments)),
            btn -> {
                cfg.confirmLargePayments = !cfg.confirmLargePayments;
                btn.setMessage(Text.literal("💰 Confirm >1B: " + onOff(cfg.confirmLargePayments)));
                CoolPaymentsConfig.save();
            }).dimensions(x, y + gap * 2, w, h).build());

        this.addDrawableChild(ButtonWidget.builder(
            Text.literal("Close  [H]"),
            btn -> this.client.setScreen(null))
            .dimensions(x, y + gap * 4, w, h).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Sidebar panel background
        context.fill(0, 0, PANEL_W, this.height, 0xE0101018);
        // Right-side separator line
        context.fill(PANEL_W - 1, 0, PANEL_W, this.height, 0x88444466);

        // Header background
        context.fill(0, 0, PANEL_W, 42, 0xEE1a1a2e);
        context.fill(0, 41, PANEL_W, 42, 0x88FF5555);

        // Title text
        context.drawTextWithShadow(this.textRenderer, "🎄 Cool Payments", 12, 10, 0xFFFFAA);
        context.drawTextWithShadow(this.textRenderer, "Settings", 12, 24, 0x888888);

        super.render(context, mouseX, mouseY, delta);
    }

    // Don't dim the game world behind the sidebar
    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {}

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public boolean shouldCloseOnEsc() { return true; }

    private String onOff(boolean value) {
        return value ? "§aON" : "§cOFF";
    }
}
