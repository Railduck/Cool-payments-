package com.coolpayments;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class PaymentConfirmScreen extends Screen {

    private final String command;   // the full command to send, without /
    private final String recipient;
    private final String amount;

    public PaymentConfirmScreen(String command, String recipient, String amount) {
        super(Text.literal("Confirm Payment"));
        this.command = command;
        this.recipient = recipient;
        this.amount = amount;
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int cy = this.height / 2;

        this.addDrawableChild(ButtonWidget.builder(
            Text.literal("✅  Yes, send it!"),
            btn -> {
                MinecraftClient client = MinecraftClient.getInstance();
                client.setScreen(null);
                if (client.getNetworkHandler() != null) {
                    client.getNetworkHandler().sendCommand(command);
                }
            }).dimensions(cx - 112, cy + 28, 108, 20).build());

        this.addDrawableChild(ButtonWidget.builder(
            Text.literal("❌  Cancel"),
            btn -> MinecraftClient.getInstance().setScreen(null))
            .dimensions(cx + 4, cy + 28, 108, 20).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);

        int cx = this.width / 2;
        int cy = this.height / 2;

        // Box background
        context.fill(cx - 125, cy - 55, cx + 125, cy + 58, 0xEE0d0d1a);

        // Red border
        int bx = cx - 125, by = cy - 55, bw = 250, bh = 113;
        context.fill(bx,          by,          bx + bw,     by + 2,      0xFFFF4444);
        context.fill(bx,          by + bh - 2, bx + bw,     by + bh,     0xFFFF4444);
        context.fill(bx,          by,          bx + 2,       by + bh,     0xFFFF4444);
        context.fill(bx + bw - 2, by,          bx + bw,     by + bh,     0xFFFF4444);

        context.drawCenteredTextWithShadow(this.textRenderer, "⚠  BIG PAYMENT WARNING",    cx, cy - 44, 0xFFFF55);
        context.drawCenteredTextWithShadow(this.textRenderer, "Sending  $" + amount,        cx, cy - 24, 0xFFFFFF);
        context.drawCenteredTextWithShadow(this.textRenderer, "to  " + recipient,           cx, cy - 8,  0xFFFFFF);
        context.drawCenteredTextWithShadow(this.textRenderer, "Are you sure?",              cx, cy + 10, 0xAAAAAA);
    }

    @Override
    public boolean shouldPause() { return false; }
}
