package com.coolpayments;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import org.joml.Vector3f;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CoolPaymentsClient implements ClientModInitializer {

    public static final Logger LOGGER = LoggerFactory.getLogger("coolpayments");

    // ── Payment detection (incoming messages) ──────────────────────────────
    private static final Pattern[] PAYMENT_PATTERNS = {
        Pattern.compile("(?i)you paid .+ \\$[\\d,.]+"),
        Pattern.compile("(?i)you received \\$[\\d,.]+ from .+"),
        Pattern.compile("(?i)payment of \\$[\\d,.]+ received"),
        Pattern.compile("(?i)transferred \\$[\\d,.]+ to .+"),
        Pattern.compile("(?i)you have been paid \\$[\\d,.]+"),
        Pattern.compile("(?i)\\$[\\d,.]+ has been (sent|transferred|paid)"),
        Pattern.compile("(?i)paid you \\$[\\d,.]+"),
        Pattern.compile("(?i)you sent .+ \\$[\\d,.]+"),
    };

    // ── Pay command interception (outgoing) ────────────────────────────────
    // Matches: pay <player> <amount>  or  money pay <player> <amount>  etc.
    private static final Pattern PAY_CMD = Pattern.compile(
        "^(?:pay|money\\s+pay|eco\\s+pay|bal\\s+pay)\\s+(\\S+)\\s+(\\S+)",
        Pattern.CASE_INSENSITIVE
    );

    // ── Jingle Bells melody ────────────────────────────────────────────────
    private static final float[] JINGLE_PITCHES = {
        1.26f, 1.26f, 1.26f,
        1.26f, 1.26f, 1.26f,
        1.26f, 1.498f, 1.0f, 1.122f, 1.26f
    };
    private static final int[] JINGLE_DELAYS = {
        0, 10, 10,
        20, 10, 10,
        20, 10, 10,
        15, 5, 20
    };

    // ── State ──────────────────────────────────────────────────────────────
    private static final List<long[]> noteQueue = new ArrayList<>();
    private static long tickCounter = 0;

    private static final DustParticleEffect RED_DUST   = new DustParticleEffect(new Vector3f(1.0f, 0.08f, 0.08f), 2.0f);
    private static final DustParticleEffect GREEN_DUST = new DustParticleEffect(new Vector3f(0.0f, 0.72f, 0.12f), 2.0f);
    private static final DustParticleEffect GOLD_DUST  = new DustParticleEffect(new Vector3f(1.0f, 0.85f, 0.0f),  1.5f);

    private KeyBinding settingsKey;

    // ── Init ───────────────────────────────────────────────────────────────
    @Override
    public void onInitializeClient() {
        LOGGER.info("🎄 Cool Payments: Christmas Edition loaded!");

        CoolPaymentsConfig.load();

        // H key opens/closes settings sidebar
        settingsKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.coolpayments.settings",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_H,
            "Cool Payments"
        ));

        // Incoming chat → trigger effects
        ClientReceiveMessageEvents.CHAT.register((message, signedMessage, sender, params, ts) -> {
            if (isPaymentMessage(message.getString())) triggerChristmasEffect();
        });
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            if (!overlay && isPaymentMessage(message.getString())) triggerChristmasEffect();
        });

        // Outgoing command → intercept large payments
        ClientSendMessageEvents.ALLOW_COMMAND.register(command -> {
            if (!CoolPaymentsConfig.get().confirmLargePayments) return true;

            Matcher m = PAY_CMD.matcher(command.trim());
            if (m.find()) {
                long amount = parseAmount(m.group(2));
                if (amount >= 1_000_000_000L) {
                    String recipient    = m.group(1);
                    String displayAmt   = formatAmount(amount);
                    MinecraftClient client = MinecraftClient.getInstance();
                    client.execute(() ->
                        client.setScreen(new PaymentConfirmScreen(command, recipient, displayAmt))
                    );
                    return false; // block the command until confirmed
                }
            }
            return true;
        });

        // Tick: fire queued notes + check keybind
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            tickCounter++;

            // Fire notes
            if (!noteQueue.isEmpty() && client.player != null && client.world != null) {
                noteQueue.removeIf(entry -> {
                    if (tickCounter >= entry[0]) {
                        float pitch = Float.intBitsToFloat((int) entry[1]);
                        client.world.playSound(client.player, client.player.getBlockPos(),
                            SoundEvents.BLOCK_NOTE_BLOCK_BELL.value(),
                            SoundCategory.PLAYERS, 0.9f, pitch);
                        return true;
                    }
                    return false;
                });
            }

            // Toggle settings sidebar
            while (settingsKey.wasPressed()) {
                if (client.currentScreen instanceof CoolPaymentsSettingsScreen) {
                    client.setScreen(null);
                } else if (client.currentScreen == null) {
                    client.setScreen(new CoolPaymentsSettingsScreen());
                }
            }
        });
    }

    // ── Effect trigger ─────────────────────────────────────────────────────
    private void triggerChristmasEffect() {
        CoolPaymentsConfig cfg = CoolPaymentsConfig.get();
        if (cfg.particlesEnabled) spawnChristmasParticles();
        if (cfg.musicEnabled)     scheduleJingleBells();
    }

    private void scheduleJingleBells() {
        int cumulative = 0;
        for (int i = 0; i < JINGLE_PITCHES.length; i++) {
            cumulative += JINGLE_DELAYS[i];
            noteQueue.add(new long[]{
                tickCounter + cumulative,
                Float.floatToIntBits(JINGLE_PITCHES[i])
            });
        }
    }

    private void spawnChristmasParticles() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) return;

        PlayerEntity player = client.player;
        ClientWorld  world  = client.world;
        double x = player.getX(), y = player.getY() + 0.5, z = player.getZ();

        for (int i = 0; i < 35; i++)
            world.addParticle(ParticleTypes.SNOWFLAKE,
                x + rand(-2.5,2.5), y + rand(1.5,4.0), z + rand(-2.5,2.5),
                rand(-0.04,0.04), -0.04, rand(-0.04,0.04));

        for (int i = 0; i < 25; i++)
            world.addParticle(RED_DUST,
                x + rand(-1.5,1.5), y + rand(0,2.5), z + rand(-1.5,1.5),
                rand(-0.2,0.2), rand(0.1,0.3), rand(-0.2,0.2));

        for (int i = 0; i < 25; i++)
            world.addParticle(GREEN_DUST,
                x + rand(-1.5,1.5), y + rand(0,2.5), z + rand(-1.5,1.5),
                rand(-0.2,0.2), rand(0.1,0.3), rand(-0.2,0.2));

        for (int i = 0; i < 20; i++)
            world.addParticle(GOLD_DUST,
                x + rand(-1.0,1.0), y + rand(0,3.0), z + rand(-1.0,1.0),
                0, rand(0.1,0.4), 0);

        for (int i = 0; i < 20; i++) {
            double angle = Math.random() * Math.PI * 2;
            double radius = 0.5 + Math.random() * 1.5;
            world.addParticle(ParticleTypes.END_ROD,
                x + Math.cos(angle)*radius, y + rand(0,2.5), z + Math.sin(angle)*radius,
                rand(-0.05,0.05), rand(0.1,0.3), rand(-0.05,0.05));
        }

        for (int i = 0; i < 12; i++) {
            double angle = (i / 12.0) * Math.PI * 2;
            world.addParticle(ParticleTypes.ENCHANT,
                x + Math.cos(angle)*0.8, y + (i/12.0)*2.0, z + Math.sin(angle)*0.8,
                rand(-0.05,0.05), 0.25, rand(-0.05,0.05));
        }

        world.playSound(player, player.getBlockPos(),
            SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, SoundCategory.PLAYERS, 0.5f, 1.5f);
    }

    // ── Helpers ────────────────────────────────────────────────────────────
    private boolean isPaymentMessage(String text) {
        for (Pattern p : PAYMENT_PATTERNS)
            if (p.matcher(text).find()) return true;
        return false;
    }

    private static long parseAmount(String s) {
        s = s.replace(",", "").trim().toLowerCase();
        try {
            if (s.endsWith("b")) return (long)(Double.parseDouble(s.replace("b","")) * 1_000_000_000);
            if (s.endsWith("m")) return (long)(Double.parseDouble(s.replace("m","")) * 1_000_000);
            if (s.endsWith("k")) return (long)(Double.parseDouble(s.replace("k","")) * 1_000);
            return (long) Double.parseDouble(s);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private static String formatAmount(long amount) {
        if (amount >= 1_000_000_000) return String.format("%.2fB", amount / 1_000_000_000.0);
        if (amount >= 1_000_000)     return String.format("%.2fM", amount / 1_000_000.0);
        return String.format("%,d", amount);
    }

    private double rand(double min, double max) {
        return min + Math.random() * (max - min);
    }
}
