package com.coolpayments;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.*;
import java.nio.file.Path;

public class CoolPaymentsConfig {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH = FabricLoader.getInstance().getConfigDir().resolve("coolpayments.json");

    public boolean particlesEnabled = true;
    public boolean musicEnabled = true;
    public boolean confirmLargePayments = true;

    private static CoolPaymentsConfig instance;

    public static CoolPaymentsConfig get() {
        if (instance == null) load();
        return instance;
    }

    public static void load() {
        File file = CONFIG_PATH.toFile();
        if (file.exists()) {
            try (Reader r = new FileReader(file)) {
                instance = GSON.fromJson(r, CoolPaymentsConfig.class);
                if (instance == null) instance = new CoolPaymentsConfig();
            } catch (Exception e) {
                instance = new CoolPaymentsConfig();
            }
        } else {
            instance = new CoolPaymentsConfig();
        }
    }

    public static void save() {
        try (Writer w = new FileWriter(CONFIG_PATH.toFile())) {
            GSON.toJson(get(), w);
        } catch (Exception e) {
            CoolPaymentsClient.LOGGER.error("Failed to save config: {}", e.getMessage());
        }
    }
}
